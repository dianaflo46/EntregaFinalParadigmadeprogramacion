﻿using RetosMathModel;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace RetosMathBussines
{
    public class ModoConvencionalBussines
    {

        /// <summary>
        /// Metodo que calcula el puntaje en modo convencional
        /// </summary>
        /// <param name="Model"></param>
        /// <returns></returns>
        public string CalcularPuntaje(ModoconvencionalModel Model)
        {
            int contador = 0, valorAcierto = 10;

            contador = calcularAciertos(contador, Model.respuestaNumero1,Model.numeroTabla, 1);
            contador = calcularAciertos(contador, Model.respuestaNumero2, Model.numeroTabla, 2);
            contador = calcularAciertos(contador, Model.respuestaNumero3, Model.numeroTabla, 3);
            contador = calcularAciertos(contador, Model.respuestaNumero4, Model.numeroTabla, 4);
            contador = calcularAciertos(contador, Model.respuestaNumero5, Model.numeroTabla, 5);
            contador = calcularAciertos(contador, Model.respuestaNumero6, Model.numeroTabla, 6);
            contador = calcularAciertos(contador, Model.respuestaNumero7, Model.numeroTabla, 7);
            contador = calcularAciertos(contador, Model.respuestaNumero8, Model.numeroTabla, 8);
            contador = calcularAciertos(contador, Model.respuestaNumero9, Model.numeroTabla, 9);
            contador = calcularAciertos(contador, Model.respuestaNumero10, Model.numeroTabla,10);

            return "Obtuviste " + contador * 10 +  " puntos de " + 10 * valorAcierto + " Posibles. N  de Tabla : " + Model.numeroTabla;
        }

        private int calcularAciertos(int contador, int respuesta, int tabla, int valor )
        {
            if (respuesta == tabla * valor)
                contador = contador + 1;
            return contador;
        } 
         

    }
}
