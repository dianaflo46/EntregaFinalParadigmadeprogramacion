﻿using RetosMathModel;

namespace RetosMathBussines
{
    public class ModoconvencionalRetos
    {
        /// <summary>
        /// Metodo que calcula el puntaje en modo reto
        /// </summary>
        /// <param name="Model"></param>
        /// <returns></returns>
        public string CalcularPuntaje(ModoretosModel Model)
        {
            if (Model.acomulado >= Model.cantidadAciertos)
                return "Felicidades supero el nivel con " + Model.acomulado + " aciertos";
            else
            {
                int faltaron = Model.cantidadAciertos - Model.acomulado;
                return "Usted tuvo " + Model.acomulado + " respuestas correctas le hicieron falta " + faltaron + " para superar el nivel";
            }
        }
    }
}
