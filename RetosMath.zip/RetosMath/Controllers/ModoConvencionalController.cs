﻿using RetosMathBussines;
using RetosMathModel;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;

namespace RetosMath.Controllers
{
    public class ModoConvencionalController : Controller
    {
        // GET: ModoConvencional
        /// <summary>
        /// Realiza la carga de la visa en modo convencional
        /// </summary>
        /// <returns></returns>
        public ActionResult Index()
        {
            ModoconvencionalModel model =null;
            if(TempData["resultado"] != null)
                ViewData["puntaje"] = TempData["resultado"].ToString(); 
            return View(model);
        }

        /// <summary>
        /// Metodo post modo convencional
        /// </summary>
        /// <param name="Model"></param>
        /// <returns></returns>
        [HttpPost]
        public ActionResult Index(ModoconvencionalModel Model)
        {
            ModoConvencionalBussines ObjBll = new ModoConvencionalBussines();
            string mensaje = ObjBll.CalcularPuntaje(Model);
            TempData["resultado"] = mensaje;
            return RedirectToAction("Index", "ModoConvencional");
        }
    }
}