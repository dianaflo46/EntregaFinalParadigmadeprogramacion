﻿using RetosMathBussines;
using RetosMathModel;
using System.Web.Mvc;

namespace RetosMath.Controllers
{
    public class ModoretosController : Controller
    {
        /// <summary>
        /// Metodo que carga la vista en modo retos
        /// </summary>
        /// <returns></returns>
        // GET: Modoretos
        public ActionResult Index()
        {

            if (TempData["resultado"] != null)
                ViewData["puntaje"] = TempData["resultado"].ToString();


            return View();
        }


        /// <summary>
        /// Metodo Post de la vista  modo retos
        /// </summary>
        /// <param name="Model"></param>
        /// <returns></returns>
        [HttpPost]
        public ActionResult Index(ModoretosModel Model)
        {
            Model.cantidadAciertos = 10;

            ModoconvencionalRetos ObjBll = new ModoconvencionalRetos();
            string mensaje = ObjBll.CalcularPuntaje(Model);
            TempData["resultado"] = mensaje;
            return RedirectToAction("Index", "Modoretos");

        }
    }
}
