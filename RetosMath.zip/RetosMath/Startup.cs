﻿using Microsoft.Owin;
using Owin;

[assembly: OwinStartupAttribute(typeof(RetosMath.Startup))]
namespace RetosMath
{
    public partial class Startup
    {
        public void Configuration(IAppBuilder app)
        {
            ConfigureAuth(app);
        }
    }
}
