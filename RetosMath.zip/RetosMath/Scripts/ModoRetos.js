﻿var tiempo = 10;
var acom = 0;

function ModoConvencional() {
    window.location.href = '/ModoConvencional/Index';
}

function ModoFacil() {
    $("#btn-facil").prop('disabled', false);
    $("#btn-inter").prop('disabled', true);
    $("#btn-dificil").prop('disabled', true);
    tiempo = 90;
    actualizarTiempo()
    $(".jugar").show();
    var aleatorio1 = Math.round(Math.random() * 10);
    var aleatorio2 = Math.round(Math.random() * 10);
    $("#numero1").html(aleatorio1)
    $("#numero2").html(aleatorio2)
}

function ModoIntermedio() {
    $("#btn-facil").prop('disabled', true);
    $("#btn-inter").prop('disabled', false);
    $("#btn-dificil").prop('disabled', true);
    tiempo = 60;
    actualizarTiempo()
    $(".jugar").show();
    var aleatorio1 = Math.round(Math.random() * 10);
    var aleatorio2 = Math.round(Math.random() * 10);
    $("#numero1").html(aleatorio1)
    $("#numero2").html(aleatorio2)

}

function ModoDificil() {
    $("#btn-facil").prop('disabled', true);
    $("#btn-inter").prop('disabled', true);
    $("#btn-dificil").prop('disabled', false);
    tiempo = 30;
    actualizarTiempo()
    $(".jugar").show();
    var aleatorio1 = Math.round(Math.random() * 10);
    var aleatorio2 = Math.round(Math.random() * 10);
    $("#numero1").html(aleatorio1)
    $("#numero2").html(aleatorio2)
}

function actualizarTiempo() {
    document.getElementById('tiempo').innerHTML = tiempo;
    if (tiempo == 0) {
        alert("Se agoto el tiempo");
        $("#btn-siguiente").prop('disabled', true);
        $("#btn-facil").prop('disabled', true);
        $("#btn-inter").prop('disabled', true);
        $("#btn-dificil").prop('disabled', true);
        $("#btn-finalizar").show();
        return false;
    }
    else {
        tiempo--;
        setTimeout("actualizarTiempo()", 1000)
    }
}

function Calcular() {

    if ($("#numero1").text() * $("#numero2").text() == $("#Respuesta").val()) {
        $("#acomulado").val(acom + 1);
        acom = acom + 1;
        $("#Correcto").show();
        $("#Incorrecto").hide();
    } else{
        $("#Incorrecto").show();
        $("#Correcto").hide();
    }

    var aleatorio1 = Math.round(Math.random() * 10);
    var aleatorio2 = Math.round(Math.random() * 10);
    $("#numero1").html(aleatorio1)
    $("#numero2").html(aleatorio2)
    $("#Respuesta").val("");

}