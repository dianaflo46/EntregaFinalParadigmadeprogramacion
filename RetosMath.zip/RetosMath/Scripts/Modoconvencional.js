﻿var segundos = 60;

function actualizarTiempo() {
    document.getElementById('tiempo').innerHTML = segundos ;
    if (segundos == 0) {
        alert("Se agoto el tiempo");
        segundos = 60;
        window.location.href = '/ModoConvencional/Index';
        return false;
    }
    else {
        segundos--;
        setTimeout("actualizarTiempo()",1000)
    }
}

function procesarTabla(numero) {
    segundos = 60;
    switch (numero) {
        case 1:
            $("#btnTabla1Ini").hide();
            $("#btnTabla1val").show();
            $(".tablaUno").prop('disabled', false);
            $(".tablaUno").prop('required', true);
            break;
        case 2:
            $("#btnTabla1Ini2").hide();
            $("#btnTabla1val2").show();
            $(".tablaDos").prop('disabled', false);
            $(".tablaDos").prop('required', true);
            break;
        case 3:
            $("#btnTabla1Ini3").hide();
            $("#btnTabla1val3").show();
            $(".tablatres").prop('disabled', false);
            $(".tablatres").prop('required', true);
            break;
        case 4:
            $("#btnTabla1Ini4").hide();
            $("#btnTabla1val4").show();
            $(".tablacuatro").prop('disabled', false);
            $(".tablacuatro").prop('required', true);
            break;
        case 5:
            $("#btnTabla1Ini5").hide();
            $("#btnTabla1val5").show();
            $(".tablaCinco").prop('disabled', false);
            $(".tablaCinco").prop('required', true);
            break;
        case 6:
            $("#btnTabla1Ini6").hide();
            $("#btnTabla1val6").show();
            $(".tablaSeis").prop('disabled', false);
            $(".tablaSeis").prop('required', true);
            break;
        case 7:
            $("#btnTabla1Ini7").hide();
            $("#btnTabla1val7").show();
            $(".tablaSiete").prop('disabled', false);
            $(".tablaSiete").prop('required', true);
            break;
        case 8:
            $("#btnTabla1Ini8").hide();
            $("#btnTabla1val8").show();
            $(".tablaOcho").prop('disabled', false);
            $(".tablaOcho").prop('required', true);
            break;
        case 9:
            $("#btnTabla1Ini9").hide();
            $("#btnTabla1val9").show();
            $(".tablaNueve").prop('disabled', false);
            $(".tablaNueve").prop('required', true);
            break;
        case 10:
            $("#btnTabla1Ini10").hide();
            $("#btnTabla1val10").show();
            $(".tablaDiez").prop('disabled', false);
            $(".tablaDiez").prop('required', true);
            break;
        default:
            // code block
    }
  
    $("#NumeroTabla").val(numero)
    actualizarTiempo();
}

function ModoRetos()
{
    window.location.href = '/Modoretos/Index';
}


