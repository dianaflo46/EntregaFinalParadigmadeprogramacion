﻿namespace RetosMathModel
{
    /// <summary>
    /// Modelo para juego modo convencional
    /// </summary>
    public class ModoconvencionalModel
    {
        public int respuestaNumero1 { get; set; }

        public int respuestaNumero2 { get; set; }

        public int respuestaNumero3 { get; set; }

        public int respuestaNumero4 { get; set; }

        public int respuestaNumero5 { get; set; }

        public int respuestaNumero6 { get; set; }

        public int respuestaNumero7 { get; set; }

        public int respuestaNumero8 { get; set; }

        public int respuestaNumero9 { get; set; }

        public int respuestaNumero10 { get; set; }

        public int numeroTabla { get; set; }

        public int tiempoEjecutado { get; set; }

        public int tiempoCorrecto { get; set; }
    }
}
