﻿namespace RetosMathModel
{
    /// <summary>
    /// Modelo para juego modo retos
    /// </summary>
    public class ModoretosModel
    {
        public int nivel { get; set; }

        public int numero1 { get; set; }

        public int numero2 { get; set; }

        public int respuesta { get; set; }

        public int acomulado { get; set; }

        public int cantidadAciertos { get; set; }
    }
}
